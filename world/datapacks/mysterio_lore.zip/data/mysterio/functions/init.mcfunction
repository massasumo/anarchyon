
tellraw @a [{"text":"[MISTÉRIO] ","color":"gold"},{"text":"Diários antigos e baús secretos foram espalhados pelo mundo!","color":"yellow"}]
setblock 120 64 -350 minecraft:oak_sign[rotation=4]{front_text:{messages:['{"text":"- DIÁRIO DE GUERRA -"}','{"text":"O 3º Clã caiu no"}','{"text":"Templo do Sul."}','{"text":"Coord: 450, 20, -120"}']}} replace
